SwiftDownload 1.2.1 (portable)

1. Keep SwiftDownload.exe, swiftdownload-host.exe and the browser-extension folder together.
2. Start SwiftDownload.exe. It registers itself with your browsers (per user, no admin rights).
   If you move the folder, start it again or click Options > Browser > "Register".
3. Install the extension: Options > Browser > "Install in ..." (or load browser-extension\chromium
   as an unpacked extension). See BROWSER-INTEGRATION.md.

Requires the Microsoft Edge WebView2 Runtime (included in Windows 10/11).
FFmpeg (optional, for combining separate video/audio streams): put ffmpeg.exe in an "ffmpeg"
folder next to SwiftDownload.exe, or set its path in Options > Media.
Settings and the download list are stored in %APPDATA%\com.swiftdownload.tauri.
